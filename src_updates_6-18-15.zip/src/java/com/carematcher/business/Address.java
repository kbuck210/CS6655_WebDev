/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.business;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Address implements Serializable {
    
    public enum AddressType {
        HOME,
        WORK,
        MAILING
    }
    private AddressType addressType = AddressType.HOME;
    
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private long addressId;
    
    private String street;
    private String city;
    private String st;
    private String zip;
    
    private double latitude;
    private double longitude;
    
    @ManyToOne(fetch=FetchType.LAZY, cascade=CascadeType.ALL)
    private User user;
    
    public long getAddressId() {
        return addressId;
    }
    
    public void setAddressId(long addressId) {
        this.addressId = addressId;
    }
    
    public String getStreet() {
        return street;
    }
    
    public void setStreet(String street) {
        if (street != null && !street.trim().isEmpty()) {
            this.street = street;
        }
    }
    
    public String getCity() {
        return city;
    }
    
    public void setCity(String city) {
        if (city != null && !city.trim().isEmpty()) {
            this.city = city;
        }
    }
    
    public String getSt() {
        return st;
    }
    
    public void setSt(String st) {
        if (st != null && !st.trim().isEmpty()) {
            this.st = st;
        }
    }
    
    public String getZip() {
        return zip;
    }
    
    public void setZip(String zip) {
        if (zip != null && !zip.trim().isEmpty()) {
            this.zip = zip;
        }
    }
    
    public double getLatitude() {
        return latitude;
    }
    
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }
    
    public double getLongitude() {
        return longitude;
    }
    
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
    
    public AddressType getAddressType() {
        return addressType;
    }
    
    public void setAddressType(AddressType type) {
        this.addressType = type;
    }
    
    public User getUser() {
        return user;
    }
    
    public void setUser(User user) {
        if (user != null) {
            if (!user.getAddresses().contains(this)) {
                user.addAddress(this);
            }
        }
        this.user = user;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        
        if (street != null && city != null && st != null && zip != null) {
            sb.append(street);
            sb.append(", ");
            sb.append(city);
            sb.append(", ");
            sb.append(st);
            sb.append(", ");
            sb.append(zip);
        }
        
        return sb.toString();
    }
}
