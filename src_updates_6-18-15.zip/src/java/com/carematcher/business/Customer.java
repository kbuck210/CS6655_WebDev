/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.business;

import com.carematcher.util.CalUtil;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/** The main Customer class, extension of the User class, storing customer- 
 * specific attributes
 * @author kbuck
 */
@Entity
public class Customer extends User {
    
    @Temporal(TemporalType.DATE)
    private GregorianCalendar dateOfBirth = new GregorianCalendar();
    
    @OneToMany(targetEntity=Review.class)
    private final Set<Review> reviews = new HashSet<Review>();
    
    @ManyToMany(targetEntity=Service.class)
    private final Set<Service> servicesDesired = new HashSet<Service>();
    
    @ManyToMany(targetEntity=Insurance.class)
    private final Set<Insurance> insurances = new HashSet<Insurance>();
    
    public Calendar getDateOfBirth() {
        return dateOfBirth;
    }
    
    public void setDateOfBirth(Date dob) {
        this.dateOfBirth.setTime(dob);
        CalUtil calendar = new CalUtil(dateOfBirth.get(GregorianCalendar.DAY_OF_MONTH),
                                       dateOfBirth.get(GregorianCalendar.MONTH),
                                       dateOfBirth.get(GregorianCalendar.YEAR));
        if (!calendar.isValidDate()) {
            this.dateOfBirth = new GregorianCalendar();
        }
    }
    
    /* --------------------------------------------------------------------
     *  Insurances
     * -------------------------------------------------------------------- */
    public Set<Insurance> getInsurances() {
        return insurances;
    }
    
    public void addInsurance(Insurance insurance) {
        if (insurance != null) {
            if (!insurance.getUsers().contains(this)) {
                insurance.addUser(this);
            }
            if (!insurances.contains(insurance)) {
                insurances.add(insurance);
            }
        }
    }
    
    public void removeInsurance(Insurance insurance) {
        if (insurance != null) {
            if (insurance.getUsers().contains(this)) {
                insurance.getUsers().remove(this);
            }
            if (insurances.contains(insurance)) {
                insurances.remove(insurance);
            }
        }
    }
    
    /* --------------------------------------------------------------------
     *  Reviews
     * -------------------------------------------------------------------- */
    public Set<Review> getReviews() {
        return reviews;
    }
    
    public void addReview(Review review) {
        if (review != null) {
            if (review.getReviewingCustomer() != this) {
                review.setReviewingCustomer(this);
            }
            if (!reviews.contains(review)) {
                reviews.add(review);
            }
        }
    }
    
    public void removeReview(Review review) {
        if (review != null) {
            if (reviews.contains(review)) {
                reviews.remove(review);
                review.setReviewingCustomer(null);
            }
        }
    }
    
    /* --------------------------------------------------------------------
     *  Services Desired
     * -------------------------------------------------------------------- */
    public Set<Service> getServicesDesired() {
        return servicesDesired;
    }
    
    public void addServiceDesired(Service service) {
        if (service != null) {
            
        }
    }
    
    public void removeServiceDesired(Service service) {
        
    }

    @Override
    public Role type() {
        return Role.CUSTOMER;
    }
}
