package com.carematcher.search;

public class LuceneConstants {
    public static final String CONTENTS="FirstName";
    public static final String FILE_NAME="filename";
    public static final String FILE_PATH="/Users/pooja/Desktop/Index";
    public static final int MAX_SEARCH = 50;
    public static final String URL = "jdbc:mysql://localhost:3306/carematcher";
    public static final String USER = "root";
    public static final String PASS = "";
}