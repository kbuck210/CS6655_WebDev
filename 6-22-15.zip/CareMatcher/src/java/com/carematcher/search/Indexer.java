package com.carematcher.search;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

import static com.carematcher.search.LuceneConstants.PASS;
import static com.carematcher.search.LuceneConstants.URL;
import static com.carematcher.search.LuceneConstants.USER;

import java.sql.* ;

public class Indexer {

    private IndexWriter writer;

    @SuppressWarnings("deprecation")
    public Indexer(String indexDirectoryPath) throws IOException{
        //this directory will contain the indexes
        Directory indexDirectory = 
        FSDirectory.open(new File(indexDirectoryPath));

        //create the indexer
        writer = new IndexWriter(indexDirectory, 
        new StandardAnalyzer(Version.LUCENE_36),true,
        IndexWriter.MaxFieldLength.UNLIMITED);
    }

    public void close() throws CorruptIndexException, IOException{
        writer.close();
    }
    
    private Document getDocument(ResultSet rs) throws IOException, SQLException {
        Document document = new Document();
	
        Field email = new Field("email", rs.getString("EMAIL"), Field.Store.YES, Field.Index.ANALYZED);
        document.add(email);
        Field firstName = new Field("firstName", rs.getString("FIRSTNAME"), Field.Store.YES, Field.Index.ANALYZED);
        document.add(firstName);
        Field lastName = new Field("lastName", rs.getString("LASTNAME"), Field.Store.YES, Field.Index.ANALYZED);
        document.add(lastName);
        Field midInit = new Field("midInit", rs.getString("MIDINIT"), Field.Store.YES, Field.Index.ANALYZED);
        document.add(midInit);
        Field dType = new Field("dType", rs.getString("DTYPE"),Field.Store.YES,Field.Index.ANALYZED);
        document.add(dType);
        Field accepting = new Field("accepting", rs.getString("ACCEPTINGNEWPATIENTS"), Field.Store.YES, Field.Index.ANALYZED);
        document.add(accepting);
        
        return document;
    }   


    private void indexDatabase(ResultSet rs) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, CorruptIndexException, IOException {
        Document document = getDocument(rs);
	writer.addDocument(document);
    }
    
    public int createIndex(String dataDirPath) 
        throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
        //connect to the database and build the queries
        Class.forName("com.mysql.jdbc.Driver").newInstance();
        Connection conn = DriverManager.getConnection(URL, USER, PASS);
        Statement stmt = conn.createStatement(); 
        //SELECT* FROM SERVICE_USER,SERVICE,USER WHERE SERVICE_USER.providers_USERID = USER.USERID AND SERVICE_USER.Service_SERVICEID = SERVICE.SERVICEID;
        String sql = "SELECT * FROM User";
        ResultSet rs = stmt.executeQuery(sql);
        while(rs.next()){
            indexDatabase(rs);
        }
	conn.close();
        return writer.numDocs();
    }
}