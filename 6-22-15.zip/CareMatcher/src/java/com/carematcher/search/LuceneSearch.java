/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.search;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.lucene.document.Document;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;

/**
 *
 * @author kbuck
 */
public class LuceneSearch {
    
    private static final String index = "/Users/kbuck/Documents/School Stuff/CS655 "
            + "- Web-Based Application Development/Term Project/CareMatcher/lucene/index";
    private static final String data = "/Users/kbuck/Documents/School Stuff/CS655 "
            + "- Web-Based Application Development/Term Project/CareMatcher/lucene/data";
    
    public static boolean reindex() {
        try {
            Indexer indexer = new Indexer(index);
            indexer.createIndex(data);
            indexer.close();
        } catch (IOException ex) {
            Logger.getLogger(LuceneSearch.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } catch (InstantiationException ex) {
            Logger.getLogger(LuceneSearch.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } catch (IllegalAccessException ex) {
            Logger.getLogger(LuceneSearch.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LuceneSearch.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        } catch (SQLException ex) {
            Logger.getLogger(LuceneSearch.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
        return true;
    }
    
    public static Map<ResultKey, Object> search(String searchQuery) {
        Map<ResultKey, Object> results = new EnumMap<ResultKey, Object>(ResultKey.class);
        
        Searcher searcher;
        try {
            searcher = new Searcher(index);
        } catch (IOException ex) {
            Logger.getLogger(LuceneSearch.class.getName()).log(Level.SEVERE, null, ex);
            return results;
        }
        TopDocs hits;
        try {
            long startTime = System.currentTimeMillis();
            hits = searcher.search(searchQuery);
            long endTime = System.currentTimeMillis();
            long totalTime = endTime - startTime;
            results.put(ResultKey.TOTAL_SEARCH_TIME, totalTime);
        } catch (IOException ex) {
            Logger.getLogger(LuceneSearch.class.getName()).log(Level.SEVERE, null, ex);
            return results;
        } catch (ParseException ex) {
            Logger.getLogger(LuceneSearch.class.getName()).log(Level.SEVERE, null, ex);
            return results;
        }
        
        List<String> emails = new ArrayList<String>();
        for(ScoreDoc scoreDoc : hits.scoreDocs) {
            Document doc;
            try {
                doc = searcher.getDocument(scoreDoc);
            } catch (IOException ex) {
                Logger.getLogger(LuceneSearch.class.getName()).log(Level.SEVERE, null, ex);
                continue;
            }
            String email = doc.get("email");
            if (email != null) emails.add(doc.get("email"));
        }
        results.put(ResultKey.EMAIL, emails);
        
        try {
            searcher.close();
        } catch (IOException ex) {
            Logger.getLogger(LuceneSearch.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return results;
    }
}
