/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.business;

import com.carematcher.util.PasswordHash;
import java.io.Serializable;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

/** Generic User class, to be extended by Customer, Provider & Practice
 *
 * @author kbuck
 */
@Entity
public abstract class User implements Serializable, Comparable {

    /** Override the comparison method for the comparable interface, 
     *  to enable the use of collections validation methods
     * @param o the object to compare
     * @return -1 if comparing object is not a user, 1 if not the same user, 0 if equal
     */
    @Override
    public int compareTo(Object o) {
        if (!(o instanceof User)) {
            return -1;
        }
        else {
            User a = (User) o;
            if (a.getEmail().equals(this.email)) return 0;
            else return 1;
        }
    }
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long userId;
    
    protected Role type;
    
    private String firstName = "firstName";
    private String lastName = "lastName";
    private String midInit = "";
    
    private String username = "username";
    private String email = "email";
    
    private String password = "password";
    
    private String biography = "";
    
    //  Profile image url -> defaults to placeholder
    private String imgUrl = "images/200x200.jpg";
    
    
    @OneToMany(mappedBy="user")
    private final Set<Address> addresses = new HashSet<Address>();
    
    @OneToMany(mappedBy="user")
    private final Set<Phone> phones = new HashSet<Phone>();
    
    @ManyToMany(targetEntity=UserRole.class)
    private final Set<UserRole> roles = new HashSet<UserRole>();
    
    public long getUserId() {
        return userId;
    }
    
    public void setUserId(long userId) {
        this.userId = userId;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName) {
        if (firstName != null && !firstName.trim().isEmpty()) {
            this.firstName = firstName.trim();
        }
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        if (lastName != null && !lastName.trim().isEmpty()) {
            this.lastName = lastName.trim();
        }
    }

    public String getMidInit() {
        return midInit;
    }
    
    public void setMidInit(String midInit) {
        if (midInit != null && !midInit.trim().isEmpty()) {
            this.midInit = midInit.trim();
        }
    }

    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        if (username != null && !username.trim().isEmpty()) {
            this.username = username.trim();
        }
    }

    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        if (password != null && !password.trim().isEmpty()) {
            try {
                this.password = PasswordHash.createHash(password);
            } catch (NoSuchAlgorithmException ex) {
                Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InvalidKeySpecException ex) {
                Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        if (email != null && !email.trim().isEmpty()) {
            this.email = email;
        }
    }
    
    public String getBiography() {
        return biography;
    }
    
    public void setBiography(String biography) {
        if (biography != null && !biography.trim().isEmpty()) {
            this.biography = biography;
        }
    }
    
    public Set<Phone> getPhones() {
        return phones;
    }
    
    public void addPhone(Phone phone) {
        if (phone != null) {
            phones.add(phone);
            
            if (phone.getUser() != this) {
                phone.setUser(this);
            }           
        }
    }
    
    public void removePhone(Phone phone) {
        if (phone != null) {
            if (phones.contains(phone)) {
                phones.remove(phone);
                phone.setUser(null);
            }
        }
    }
    
    public Set<Address> getAddresses() {
        return addresses;
    }
    
    public Address getPrimaryAddress() {
        for (Address a : addresses) {
            if (a.isPrimaryAdd()) return a;
        }
        return null;
    }
    
    public void addAddress(Address address) {
        if (address != null) {
            addresses.add(address);
        
            if (address.getUser() != this) {
                address.setUser(this);
            }
            
            if (address.isPrimaryAdd()) {
                for (Address a : addresses) {
                    if (!a.equals(address)) {
                        a.setPrimaryAdd(false);
                    }
                }
            }
        }
    }
    
    public void removeAddress(Address address) {
        if (address != null) {
            if (addresses.contains(address)) {
                addresses.remove(address);
                address.setUser(null);
            }
        }
    }
    
    public String getImgUrl() {
        return imgUrl;
    }
    
    public void setImgUrl(String imgUrl) {
        if (imgUrl != null && !imgUrl.trim().isEmpty()) {
            this.imgUrl = imgUrl;
        }
    }
    
    public Set<UserRole> getRoles() {
        return roles;
    }
    
    public void addRole(UserRole role) {
        if (role != null) {
            roles.add(role);
        }
    }
    
    public void removeRole(UserRole role) {
        if (role != null && roles.contains(role)) {
            roles.remove(role);
        }
    }
    
    public void clearRoles() {
        roles.clear();
    }
    
    public Role getType() {
        return type;
    }
 
    public String getTypeString() {
        return type.toString();
    }

    public abstract void setType();
}
