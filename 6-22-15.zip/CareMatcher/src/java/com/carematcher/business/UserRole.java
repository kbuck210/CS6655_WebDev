/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.business;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

/**
 *
 * @author kbuck
 */
@Entity
public class UserRole implements Serializable {
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int user_role;
    
    private String rolename;
    
    @ManyToMany(targetEntity=User.class, fetch=FetchType.LAZY, cascade=CascadeType.ALL)
    private final Set<User> users = new HashSet<User>();
    
    public UserRole() {
        rolename = Role.CUSTOMER.toString();
        user_role = Role.CUSTOMER.ordinal();
    }
    
    public UserRole(Role role) {
        if (role != null) {
            rolename = role.toString();
            this.user_role = role.ordinal();
        }
        else {
            rolename = Role.CUSTOMER.toString();
            this.user_role = Role.CUSTOMER.ordinal();
        }
    }
    
    public Role getRole() {
        return Role.values()[user_role];
    }
    
    public void setRole(Role role) {
        if (role != null) {
            this.user_role = role.ordinal();
            this.rolename = role.toString();
        }
    }
    
    public Set<User> getUsers() {
        return users;
    }
    
    public void addUser(User user) {
        if (user != null) {
            users.add(user);
        }
    }
    
    public void removeUser(User user) {
        if (users.contains(user)) {
            users.remove(user);
        }
    }
    
    public String getRoleName() {
        return rolename;
    }
}
