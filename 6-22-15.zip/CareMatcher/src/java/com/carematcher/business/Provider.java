/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.business;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;

/** The main provider class, extension of the user class, storing provider-
 * specific information
 * @author kbuck
 */
@Entity
public class Provider extends User {
    
    private boolean willTravel = false;
    private boolean acceptingNewPatients = false;
    private String availability = "";
    private int yearsPracticing = 0;
    
    @ManyToMany(targetEntity=License.class)
    private final Set<License> licenses = new HashSet<License>();
    
    @ManyToMany(targetEntity=Service.class)
    private final Set<Service> servicesPerformed = new HashSet<Service>();
    
    @ManyToMany(targetEntity=Practice.class)
    private final Set<Practice> practicesWorkedAt = new HashSet<Practice>();
    
    @ManyToMany(targetEntity=Provider.class, fetch=FetchType.LAZY, cascade=CascadeType.ALL)
    private final Set<Customer> linkedCustomers = new HashSet<Customer>();

    public Provider() {
        setType();
    }
    
    public boolean isWillTravel() {
        return willTravel;
    }    
    
    public void setWillTravel(boolean willTravel) {
        this.willTravel = willTravel;
    }

    public boolean isAcceptingNewPatients() {
        return acceptingNewPatients;
    }
    
    public void setAcceptingNewPatients(boolean acceptingNewPatients) {
        this.acceptingNewPatients = acceptingNewPatients;
    }

    public String getAvailability() {
        return availability;
    }
    
    public void setAvailability(String availability) {
        if (availability != null && !availability.trim().isEmpty()) {
            this.availability = availability;
        }
    }

    public int getYearsPracticing() {
        return yearsPracticing;
    }    
    
    public void setYearsPracticing(int yearsPracticing) {
        if (yearsPracticing > 0) {
            this.yearsPracticing = yearsPracticing;
        }
    }
    
    public Set<License> getLicenses() {
        return licenses;
    }
    
    public void addLicense(License license) {
        if (license != null) {
            licenses.add(license);
            
            if (!license.getProvidersWithLicense().contains(this)) {
                license.addProviderWithLicense(this);
            }
        }
    }
    
    public void removeLicense(License license) {
        if (license != null) {
            if (license.getProvidersWithLicense().contains(this)) {
                license.removeProviderWithLicense(this);
            }
            if (licenses.contains(license)) {
                licenses.remove(license);
            }
        }
    }

    public Set<Service> getServicesPerformed() {
        return servicesPerformed;
    }
    
    public void addServicePerformed(Service service) {
        if (service != null) {
            servicesPerformed.add(service);
            
            if (!service.getProviders().contains(this)) {
                service.addProvider(this);
            }
        }
    }
   
    public void removeServicePerformed(Service service) {
        if (service != null) {
            if (service.getProviders().contains(this)) {
                service.removeProvider(this);
            }
            if (servicesPerformed.contains(service)) {
                servicesPerformed.remove(service);
            }
        }
    }
    
    public Set<Practice> getPracticesWorkedAt() {
        return practicesWorkedAt;
    }
    
    public void addPracticeWorkedAt(Practice practice) {
        if (practice != null) {
            practicesWorkedAt.add(practice);
            
            if (!practice.getProvidersAtPractice().contains(this)) {
                practice.addProviderAtPractice(this);
            }
        }
    }
    
    public void removePracticeWorkedAt(Practice practice) {
        if (practice != null) {
            if (practice.getProvidersAtPractice().contains(this)) {
                practice.removeProviderAtPractice(this);
            }
            if (practicesWorkedAt.contains(practice)) {
                practicesWorkedAt.remove(practice);
            }
        }
    }
    
    public Set<Customer> getLinkedCustomers() {
        return this.linkedCustomers;
    }
    
    public void addCustomer(Customer customer) {
        if (customer != null) {
            linkedCustomers.add(customer);
            
            if (!customer.getLinkedProviders().contains(this)) {
                customer.addLinkedProvider(this);
            }
        }
    }
    
    public void removeCustomer(Customer customer) {
        if (customer != null) {
            if (customer.getLinkedProviders().contains(this)) {
                customer.removeLinkedProvider(this);
            }
            if (linkedCustomers.contains(customer)) {
                linkedCustomers.remove(customer);
            }
        }
    }
    
    @Override
    public boolean equals(Object o) {
        if (o instanceof Provider) {
            Provider a = (Provider) o;
            
            if (a.getUsername().equals(this.getUsername()))
                return true;
        }
        
        return false;
    }

    /**
     *
     * @return
     */
    @Override
    public final void setType() {
        super.type = Role.PROVIDER;
    }
}
