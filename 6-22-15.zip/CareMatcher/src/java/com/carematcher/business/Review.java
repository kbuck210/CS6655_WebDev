/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.business;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 *
 * @author kbuck
 */
@Entity
public class Review implements Serializable {
    
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private long reviewId;
    
    private double rating = 0.0;
    private String review = "";
    
    @ManyToOne(fetch=FetchType.LAZY, cascade=CascadeType.ALL)
    private Customer reviewingCustomer;
    
    @ManyToOne(fetch=FetchType.LAZY, cascade=CascadeType.ALL)
    @JoinColumn(name="providerReviewed_userId")
    private Provider providerReviewed;
    
    public long getReviewId() {
        return reviewId;
    }
    
    public void setReviewId(long reviewId) {
        this.reviewId = reviewId;
    }
 
    public double getRating() {
        return rating;
    }    
    
    public void setRating(double rating) {
        if (rating >= 0.0 && rating <= 5.0) {
            this.rating = rating;
        }
    }
 
    public String getReview() {
        return review;
    }    
    
    public void setReview(String review) {
        if (review != null && !review.trim().isEmpty()) {
            this.review = review;
        }
    }
 
    public Customer getReviewingCustomer() {
        return reviewingCustomer;
    }    
    
    public void setReviewingCustomer(Customer customer) {
        if (customer != null) {
            if (!customer.getReviews().contains(this)) {
                customer.getReviews().add(this);
            }
        }
        reviewingCustomer = customer;
    }

    public Provider getProviderReviewed() {
        return providerReviewed;
    }
    
    public void setProviderReviewed(Provider provider) {
        //
    }
}
