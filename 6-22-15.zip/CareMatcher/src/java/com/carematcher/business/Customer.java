/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.business;

import com.carematcher.util.CalUtil;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/** The main Customer class, extension of the User class, storing customer- 
 * specific attributes
 * @author kbuck
 */
@Entity
public class Customer extends User {
    
    @Temporal(TemporalType.DATE)
    private GregorianCalendar dateOfBirth = new GregorianCalendar();
    
    @OneToMany(targetEntity=Review.class)
    private final Set<Review> reviews = new HashSet<Review>();
    
    @ManyToMany(targetEntity=Service.class)
    private final Set<Service> servicesDesired = new HashSet<Service>();
    
    @ManyToMany(targetEntity=Insurance.class)
    private final Set<Insurance> insurances = new HashSet<Insurance>();
    
    @ManyToMany(targetEntity=Provider.class)
    private final Set<Provider> linkedProviders = new HashSet<Provider>();
    
    public Customer() {
        setType();
    }
    
    public Calendar getDateOfBirth() {
        return dateOfBirth;
    }
    
    public void setDateOfBirth(Date dob) {
        this.dateOfBirth.setTime(dob);
        CalUtil calendar = new CalUtil(dateOfBirth.get(GregorianCalendar.DAY_OF_MONTH),
                                       dateOfBirth.get(GregorianCalendar.MONTH),
                                       dateOfBirth.get(GregorianCalendar.YEAR));
        if (!calendar.isValidDate()) {
            this.dateOfBirth = new GregorianCalendar();
        }
    }
    
    /* --------------------------------------------------------------------
     *  Insurances
     * -------------------------------------------------------------------- */
    public Set<Insurance> getInsurances() {
        return insurances;
    }
    
    public void addInsurance(Insurance insurance) {
        if (insurance != null) {
            insurances.add(insurance);
            
            if (!insurance.getUsers().contains(this)) {
                insurance.addUser(this);
            }
        }
    }
    
    public void removeInsurance(Insurance insurance) {
        if (insurance != null) {
            if (insurance.getUsers().contains(this)) {
                insurance.getUsers().remove(this);
            }
            if (insurances.contains(insurance)) {
                insurances.remove(insurance);
            }
        }
    }
    
    /* --------------------------------------------------------------------
     *  Reviews
     * -------------------------------------------------------------------- */
    public Set<Review> getReviews() {
        return reviews;
    }
    
    public void addReview(Review review) {
        if (review != null) {
            reviews.add(review);
            
            if (review.getReviewingCustomer() != this) {
                review.setReviewingCustomer(this);
            }
        }
    }
    
    public void removeReview(Review review) {
        if (review != null) {
            if (reviews.contains(review)) {
                reviews.remove(review);
                review.setReviewingCustomer(null);
            }
        }
    }
    
    /* --------------------------------------------------------------------
     *  Services Desired
     * -------------------------------------------------------------------- */
    public Set<Service> getServicesDesired() {
        return servicesDesired;
    }
    
    public void addServiceDesired(Service service) {
        if (service != null) {
            servicesDesired.add(service);
            
            if (!service.getCustomers().contains(this)) {
                service.addCustomer(this);
            }
        }
    }
    
    public void removeServiceDesired(Service service) {
        if (service != null) {
            if (service.getCustomers().contains(this)) {
                service.removeCustomer(this);
            }
            if (servicesDesired.contains(service)) {
                servicesDesired.remove(service);
            }
        }
    }
    
    public Set<Provider> getLinkedProviders() {
        return linkedProviders;
    }
    
    public void addLinkedProvider(Provider provider) {
        if (provider != null) {
            linkedProviders.add(provider);
            
            if (!provider.getLinkedCustomers().contains(this)) {
                provider.addCustomer(this);
            }
        }
    }
    
    public void removeLinkedProvider(Provider provider) {
        if (provider != null) {
            
        }
        if (linkedProviders.contains(provider)) {
            linkedProviders.remove(provider);
        }
    }

    @Override
    public final void setType() {
        this.type = Role.CUSTOMER;
    }
}
