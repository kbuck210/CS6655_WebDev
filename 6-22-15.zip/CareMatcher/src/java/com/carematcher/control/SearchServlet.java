/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.control;

import com.carematcher.business.Role;
import com.carematcher.business.User;
import com.carematcher.data.UserDB;
import com.carematcher.search.LuceneSearch;
import com.carematcher.search.ResultKey;
import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author kbuck
 */
public class SearchServlet extends HttpServlet {

    private static final int MAX_RESULTS = 10;
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String url = "/home";
        String searchString = request.getParameter("search-string");
        Map<ResultKey, Object> searchResults;
        List<User> userResults;
        String searchTime = "0.0 s";
        
        //  If the search contains text, perform lucene search
        if (searchString != null) {
            //  For testing, reindex the database
            if (LuceneSearch.reindex()) {
                //  Perform a search on the query string
                searchResults = userSearch(searchString);
                //  Get the search time & user list
                if (searchResults.containsKey(ResultKey.TOTAL_SEARCH_TIME)) {
                    StringBuilder sb = new StringBuilder();
                    long millis = ((Long)searchResults.get(ResultKey.TOTAL_SEARCH_TIME));
                    double seconds = ((double)millis)/((double)1000);
                    String secs = String.format("%.3f", seconds);
                    sb.append(secs);
                    sb.append(" s");
                    searchTime = sb.toString();
                }
                if (searchResults.containsKey(ResultKey.SEARCH_RESULTS)) {
                    userResults = (List<User>)searchResults.get(ResultKey.SEARCH_RESULTS);
                }
                else userResults = new ArrayList<User>();
                
                request.setAttribute("searchTime", searchTime);
                request.setAttribute("searchResults", userResults);
                
                url = "/searchResults.jsp";
            }
            else request.setAttribute("errorMessage", "Failed index");
        }
        
        getServletContext()
                .getRequestDispatcher(url)
                .forward(request, response);
    }
    
    /** Perform a Lucene Search based on the supplied query
     * 
     * @param query the query string from the search bar
     * @return a Map keyed by the ResultKey enums for the given search
     */
    private Map<ResultKey, Object> userSearch(String query) {
        Map<ResultKey, Object> allResults = new EnumMap<ResultKey, Object>(ResultKey.class);
        query = query.trim();   //  trim the query in case there is leading/trailing whitespace

        //  Step 1: perform a search on the literal search string
        Map<ResultKey, Object> literalResults = literalUserSearch(query);
        allResults.put(ResultKey.TOTAL_SEARCH_TIME, literalResults.get(ResultKey.TOTAL_SEARCH_TIME));
        int count = checkResults(literalResults);
        
        //  If less than the MAX_RESULTS were returned, perform more searches
        if (count <= MAX_RESULTS) {
            //  Add all of the results to the map if any returned
            if (count > 0) allResults.putAll(literalResults);  
            //  Perform a search with a trailing wildcard & update results
            Map<ResultKey, Object> wildResults = wildcardUserSearch(query);
            updateResults(allResults, wildResults);
        }
        //  If more than MAX_RESULTS was returned, limit the results
        else if (count > MAX_RESULTS) {
            List<User> users = (List<User>) literalResults.get(ResultKey.SEARCH_RESULTS);
            List<User> usersToAdd = new ArrayList<User>();
            for (int i = 0; i < MAX_RESULTS; i++) {
                usersToAdd.add(users.get(i));
            }
            allResults.put(ResultKey.SEARCH_RESULTS, usersToAdd);
        }
        
        return allResults;
    }
    
    /** Perform a query based on the literal string entered by the user
     * 
     * @param literalQuery the user-entered query string
     * @return a search results map, with the SEARCH_RESULTS key added
     */
    private Map<ResultKey, Object> literalUserSearch(String literalQuery) {
        Map<ResultKey, Object> searchResults = LuceneSearch.search(literalQuery);
        List<User> users = getResultingUsers(searchResults);
        searchResults.put(ResultKey.SEARCH_RESULTS, users);
        
        return searchResults;
    }
    
    /** Perform a query on the literal string from the user, surrounded by wildcards
     * 
     * @param literalQuery the user-entered query string
     * @return a search results map, with the SEARCH_RESULTS key added
     */
    private Map<ResultKey, Object> wildcardUserSearch(String literalQuery) {
        String wildcardSearch = literalQuery + "*";
        return literalUserSearch(wildcardSearch);
    }

    /** Based on the results of the Luncne search, get a list of Users from the DB
     * 
     * @param resultmap the Lucene search results
     * @return a list of User objects for the emails returned by Lucene
     */
    private List<User> getResultingUsers(Map<ResultKey, Object> resultmap) {
        //  Create an arraylist to store the resulting users
        List<User> results = new ArrayList<User>();
        //  If there are no resulting emails, return an empty list
        if (!resultmap.containsKey(ResultKey.EMAIL)) return results;
        
        List<String> emailresults = (List<String>) resultmap.get(ResultKey.EMAIL);
        for (String email : emailresults) {
            User result = UserDB.selectUserByEmail(email);
            if (result != null && !result.getType().equals(Role.CUSTOMER)) 
                results.add(result);
        }
        
        return results;
    }
    
    private int checkResults(Map<ResultKey, Object> results) {
        return ((List<User>) results.get(ResultKey.SEARCH_RESULTS)).size();
    }
    
    /** Update the results of the last search with the current result set
     * 
     * @param results the overall result set
     * @param update the result set from the last search
     * @return false if not MAX_RESULTS met, true otherwise
     */
    private void updateResults(Map<ResultKey, Object> results, Map<ResultKey, Object> update) {
        long total_time = ((Long)results.get(ResultKey.TOTAL_SEARCH_TIME));
        long update_time = ((Long)update.get(ResultKey.TOTAL_SEARCH_TIME));
        total_time += update_time;
        
        List<User> update_users = (List<User>)update.get(ResultKey.SEARCH_RESULTS);
        List<User> total_users = (List<User>)results.get(ResultKey.SEARCH_RESULTS);
        boolean modified = false;
        for (User u : update_users) {
            if (total_users.size() < MAX_RESULTS) {
                if (!total_users.contains(u)) {
                    total_users.add(u);
                    modified = true;
                }
            }
            else break;
        }
        
        results.put(ResultKey.TOTAL_SEARCH_TIME, total_time);
        if (modified) {
            results.put(ResultKey.SEARCH_RESULTS, total_users);
        }
    }
    
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
