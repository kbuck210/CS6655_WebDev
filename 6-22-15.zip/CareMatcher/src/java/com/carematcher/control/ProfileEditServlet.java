/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.control;

import com.carematcher.business.Customer;
import com.carematcher.business.Practice;
import com.carematcher.business.Provider;
import com.carematcher.business.Role;
import com.carematcher.business.User;
import com.carematcher.data.CustomerDB;
import com.carematcher.data.PracticeDB;
import com.carematcher.data.ProviderDB;
import com.carematcher.data.UserDB;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author kbuck
 */
public class ProfileEditServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        //  Get the user for the session
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        //  Check that the user is not null
        if (user != null) {
            //  Get the request parameters
            String service = request.getParameter("service");
            //  Check if the service is to link a user to this User
            if ("link-user".equals(service)) {
                String email = request.getParameter("userid");
                User linked = UserDB.selectUserByEmail(email);
                linkUser(user, linked);
                getServletContext().getRequestDispatcher("/home").forward(request, response);
            }
            else {
                String newBioText = request.getParameter("bio");

                //  If updating the Biography
                if (newBioText != null && !newBioText.trim().isEmpty()) {
                    User u = UserDB.selectUserByEmail(user.getEmail());
                    u.setBiography(newBioText);
                    UserDB.updateUser(u);
                    session.setAttribute("user", u);    //  Update the session user
                }
            }
        }
    }
    
    private void updateUser(User user) {
        switch(user.getType()) {
            case CUSTOMER:
                Customer c = CustomerDB.selectCustomerByEmail(user.getEmail());
                CustomerDB.update(c);
                break;
            case PROVIDER:
                Provider p = (Provider) user;
                ProviderDB.update(p);
                break;
            case PRACTICE:
                Practice pr = (Practice) user;
                PracticeDB.update(pr);
                break;
            case DEFAULT:
                break;
        }
    }
    
    private void linkUser(User target, User linked) {
        if (target.getType().equals(Role.CUSTOMER)) {
            Customer customer = (Customer) target;
            switch(linked.getType()) {
                case PROVIDER:
                    Provider p = (Provider) linked;
                    customer.addLinkedProvider(p);
                    updateUser(customer);
                    break;
                default:
                    break;
            }
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
