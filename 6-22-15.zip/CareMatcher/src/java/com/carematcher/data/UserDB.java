/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.data;

import com.carematcher.business.User;
import com.carematcher.business.Role;
import com.carematcher.util.DBUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.TypedQuery;

/**
 *
 * @author kbuck
 */
public class UserDB {
    
    /*
     *  No Insert Methods because each user is inserted into it's
     *  own table. Queries independent of user type will appear here
     */
    /** Update a generic user object in the database
     * 
     * @param user
     * @return 
     */
    public static boolean updateUser(User user) {
        if (user == null) return false;
        
        boolean success = true;
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();
        try {
            if (!trans.isActive()) trans.begin();
            em.merge(user);
            trans.commit();
        } catch (Exception e) {
            if (trans.isActive()) trans.rollback();
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, e);
            success = false;
        }
        
        return success;
    }
    
    /** Delete a generic user object from the database
     * 
     * @param user
     * @return 
     */
    public static boolean deleteUser(User user) {
        if (user == null) return false;
        
        boolean success = true;
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();
        try {
            if (!trans.isActive()) trans.begin();
            em.remove(user);
            trans.commit();
        } catch (Exception e) {
            if (trans.isActive()) trans.rollback();
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, e);
            success = false;
        }
        
        return success;
    }
    
    /** Query the Users table for the specified email
     * 
     * @param email the email address to search for
     * @return true if the email is found in the table, false otherwise
     */
    public static boolean emailExists(String email) {
        return selectUserByEmail(email) != null;
    }
    
    /** Performs a SELECT from the Users table given the specified email to return
     *  the user associated to the email address
     * 
     * @param email the email address to search
     * @return the User object from the User table for the specified user
     */
    public static User selectUserByEmail(String email) {
        if (email != null) {
            EntityManager em = DBUtil.getEmFactory().createEntityManager();
            String query = "SELECT u FROM User u WHERE u.email = :email";
            TypedQuery<User> tq = em.createQuery(query, User.class);
            tq.setParameter("email", email);
            User result = null;
            try {
               result = tq.getSingleResult();
            } catch (NoResultException e) {
                
            } catch (NonUniqueResultException e) {
                
            } catch (Exception e) {
                
            } finally {
                em.close();
            }
            
            return result;
        }
        else return null;
    }
    
    /** Queries the database to determine whether the specifed username is
     * associated with an existing User object
     * @param username the username to search the database for
     * @return true if a single user is found, false otherwise
     */
    public static boolean usernameExists(String username) {
        return selectUserByUsername(username) != null;
    }
    
    /** Get a User object from the Database using 'username' as the predicate
     * 
     * @param username the Username string to search the user table for
     * @return the User object whose username was found, null if no results or duplicate
     */
    public static User selectUserByUsername(String username) {
        User result = null;
        
        if (username != null ){
            EntityManager em = DBUtil.getEmFactory().createEntityManager();
            String query = "SELECT u FROM User u WHERE u.USERNAME = :username";
            TypedQuery<User> tq = em.createQuery(query, User.class);
            tq.setParameter("username", username);
            try {
                result = tq.getSingleResult();
            } catch (NoResultException e) {
                
            } catch (NonUniqueResultException e) {
                
            } finally {
                em.close();
            }
        }
        
        return result;
    }
    
    /** Selects all users from the User table
     * 
     * @return 
     */
    public static List<User> selectAllUsers() {
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String query = "SELECT u FROM User u";
        TypedQuery<User> tq = em.createQuery(query, User.class);
        List<User> users = new ArrayList<User>();
        try {
            users.addAll(tq.getResultList());
        } catch (NoResultException e) {
            
        } catch (Exception e) {
            
        } finally {
            em.close();
        }
        
        return users;
    }
    
    public static boolean assignRole(User user, Role role) {
        boolean success = true;
        switch(role) {
            case ADMINISTRATOR:
                
                break;
            case CUSTOMER:
                break;
            case PROVIDER:
                break;
            case PRACTICE:
                break;
            default:
                success = false;
                break;
        }
        
        return success;
    }
} 
