/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.search;

/**
 *
 * @author kbuck
 */
public enum SearchType {
    
    /** Search for any user
     * 
     */
    USER,
    
    /** Search specifically for providers
     * 
     */
    PROVIDER,
    
    /** Search specifically for practices
     * 
     */
    PRACTICE,
    
    /** For searching for services by either name or description
     * 
     */
    SERVICE,
    
    /** For searching for services by the name field only (service lookup)
     * 
     */
    SERVICE_BY_NAME,
    
    /** For searching specifically for insurances
     * 
     */
    INSURANCE,
    
    /** For searching specifically for licenses 
     * 
     */
    LICENSE
}
