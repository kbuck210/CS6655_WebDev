/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.search;

/**
 *
 * @author kbuck
 */
public enum ResultKey {
    
    TOTAL_SEARCH_TIME,
    SEARCH_RESULTS,
    EMAIL,
    SERVICE,
    LICENSE,
    INSURANCE
    
}
