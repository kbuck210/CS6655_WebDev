/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function(){
    $("#service-search").autocomplete({
        source: function (request, response) {
            $.ajax({
                url: "editProfile",
                data: {"query":request.term, "service":"service-search"},
                success: function (data) {
                    var services = data.split(":");
                    response(services);
                }
            });
        }
    });
});

