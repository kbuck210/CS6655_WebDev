/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.data;

import com.carematcher.business.Address;
import com.carematcher.util.DBUtil;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

/**
 *
 * @author kbuck
 */
public class AddressDB {
    
    public static void insert(Address address) {
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();
        try {
            em.persist(address);
            trans.commit();
        } catch (Exception e) {
            trans.rollback();
        } finally {
            em.close();
        }
    }
    
    public static void update(Address address) {
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();
        try {
            em.merge(address);
            trans.commit();
        } catch (Exception e) {
            trans.rollback();
        } finally {
            em.close();
        }
    }
    
    public static void delete(Address address) {
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();
        try {
            em.remove(address);
            trans.commit();
        } catch (Exception e) {
            trans.rollback();
        } finally {
            em.close();
        }
    }
    
    public static List<Address> selectAddresses() {
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String query = "SELECT a FROM Address a";
        TypedQuery<Address> tq = em.createQuery(query, Address.class);
        List<Address> addresses = new ArrayList<Address>();
        try {
            addresses.addAll(tq.getResultList());
        } catch (NoResultException e) {
            // No Addresses in the DB
        } finally {
            em.close();
        }
        
        return addresses;
    }
}
