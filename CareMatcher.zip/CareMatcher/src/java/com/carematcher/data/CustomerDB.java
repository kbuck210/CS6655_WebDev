/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.data;

import com.carematcher.business.Customer;
import com.carematcher.util.DBUtil;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

/**
 *
 * @author kbuck
 */
public class CustomerDB {
    
    /* ----------------------------------------------------------------------
     *  Database Modifications
     * ---------------------------------------------------------------------- */
    /**
     * 
     * @param customer 
     */
    public static void insert(Customer customer) {
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();
        try {
            em.persist(customer);
            trans.commit();
        } catch (Exception e) {
            trans.rollback();
        } finally {
            em.close();
        }
    }
    
    /**
     * 
     * @param customer 
     */
    public static void update(Customer customer) {
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();
        try {
            em.merge(customer);
            trans.commit();
        } catch (Exception e) {
            trans.rollback();
        } finally {
            em.close();
        }
    }
    
    /**
     * 
     * @param customer 
     */
    public static void delete(Customer customer) {
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();
        try {
            em.remove(customer);
            trans.commit();
        } catch (Exception e) {
            trans.rollback();
        } finally {
            em.close();
        }
    }
    
    /* ----------------------------------------------------------------------
     *  Database Queries
     * ---------------------------------------------------------------------- */
    /**
     * 
     * @param email
     * @return 
     */
    public static Customer selectCustomerByEmail(String email) {
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String query = "SELECT c FROM User c "
                     + "WHERE TYPE(c) = :type "
                     + "AND c.email = :email";
        TypedQuery<Customer> tq = em.createQuery(query, Customer.class);
        tq.setParameter("type", Customer.class);
        tq.setParameter("email", email);
        Customer result = null;
        try {
            result = tq.getSingleResult();
        } catch (Exception e) {
            
        } finally {
            em.close();
        }
        
        return result;
    }
    
    /**
     * 
     * @return 
     */
    public static List<Customer> selectAllCustomers() {
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String query = "SELECT u FROM User u "
                     + "WHERE TYPE(u) = :type";
        TypedQuery tq = em.createQuery(query, Customer.class);
        tq.setParameter("type", Customer.class);
        
        List<Customer> results = new ArrayList<Customer>();
        try {
            results.addAll(tq.getResultList());
        } catch (Exception e) {
            
        } finally {
            em.close();
        }
        
        return results;
    }
}
