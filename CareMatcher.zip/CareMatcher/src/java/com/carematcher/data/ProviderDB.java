/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.data;

import com.carematcher.business.Provider;
import com.carematcher.util.DBUtil;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.TypedQuery;

/**
 *
 * @author kbuck
 */
public class ProviderDB {
    
    /* ----------------------------------------------------------------------
     *  Database Modifications
     * ---------------------------------------------------------------------- */
    /** Persist a Provider
     * 
     * @param provider the Provider object to insert into the DB
     */
    public static void insert(Provider provider) {
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();
        try {
            em.persist(provider);
            trans.commit();
        } catch (Exception e) {
            trans.rollback();
        } finally {
            em.close();
        }
    }
    
    /** Merge an existing Provider
     * 
     * @param provider the Provider to update in the DB
     */
    public static void update(Provider provider) {
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();
        try {
            em.merge(provider);
            trans.commit();
        } catch (Exception e) {
            trans.rollback();
        } finally {
            em.close();
        }
    }
    
    /** Remove a provider
     * 
     * @param provider the Provider to delete from the DB
     */
    public static void delete(Provider provider) {
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();
        try {
            em.remove(provider);
            trans.commit();
        } catch (Exception e) {
            trans.rollback();
        } finally {
            em.close();
        }
    }
    
    /* ----------------------------------------------------------------------
     *  Database Queries
     * ---------------------------------------------------------------------- */
    /** Get a list of all providers
     * 
     * @return a List of providers in the Database
     */
    public static List<Provider> selectAllProviders() {
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String query = "SELECT p FROM User p "
                     + "WHERE TYPE(p) = :type";
        TypedQuery<Provider> tq = em.createQuery(query, Provider.class);
        tq.setParameter("type", Provider.class);
        List<Provider> results = new ArrayList<Provider>();
        try {
            results.addAll(tq.getResultList());
        } catch (NoResultException e) {
            
        } catch (Exception e) {
            
        } finally {
            em.close();
        }
        
        return results;
    }
    
    /** Select a specific provider based on the provider email
     * 
     * @param email the email for the registered provider
     * @return the Provider object result from the DB query
     */
    public static Provider selectProviderByEmail(String email) {
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String query = "SELECT p FROM User p "
                     + "WHERE TYPE(p) = :type "
                     + "AND p.email = :email";
        TypedQuery<Provider> tq = em.createQuery(query, Provider.class);
        tq.setParameter("type", Provider.class);
        tq.setParameter("email", email);
        Provider provider = null;
        try {
            provider = tq.getSingleResult();
        } catch (NoResultException e) {
            
        } catch (NonUniqueResultException e) {
       
        } catch (Exception e) {
            
        } finally {
            em.close();
        }
        
        return provider;
    }
    
    
}
