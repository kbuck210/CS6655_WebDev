/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.data;

import com.carematcher.business.User;
import com.carematcher.util.DBUtil;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.TypedQuery;

/**
 *
 * @author kbuck
 */
public class UserDB {
    
    /*
     *  No Insert/Update/Delete Methods because each user is inserted into it's
     *  own table. Queries independent of user type will appear here
     */
    
    /** Query the Users table for the specified email
     * 
     * @param email the email address to search for
     * @return true if the email is found in the table, false otherwise
     */
    public static boolean emailExists(String email) {
        boolean exists = false;
        
        if (email != null) {
            exists = (selectUserByEmail(email) != null);
        }
        
        return exists;
    }
    
    /** Performs a SELECT from the Users table given the specified email to return
     *  the user associated to the email address
     * 
     * @param email the email address to search
     * @return the User object from the User table for the specified user
     */
    public static User selectUserByEmail(String email) {
        if (email != null) {
            EntityManager em = DBUtil.getEmFactory().createEntityManager();
            String query = "SELECT u FROM User u WHERE u.email = :email";
            TypedQuery<User> tq = em.createQuery(query, User.class);
            tq.setParameter("email", email);
            User result = null;
            try {
               result = tq.getSingleResult();
            } catch (NoResultException e) {
                
            } catch (NonUniqueResultException e) {
                
            } catch (Exception e) {
                
            } finally {
                em.close();
            }
            
            return result;
        }
        else return null;
    }
    
    /** Selects all users from the User table
     * 
     * @return 
     */
    public static List<User> selectAllUsers() {
        EntityManager em = DBUtil.getEmFactory().createEntityManager();
        String query = "SELECT u FROM User u";
        TypedQuery<User> tq = em.createQuery(query, User.class);
        List<User> users = new ArrayList<User>();
        try {
            users.addAll(tq.getResultList());
        } catch (NoResultException e) {
            
        } catch (Exception e) {
            
        } finally {
            em.close();
        }
        
        return users;
    }
}
