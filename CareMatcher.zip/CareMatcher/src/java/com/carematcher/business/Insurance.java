/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.business;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

/**
 *
 * @author kbuck
 */
@Entity
public class Insurance implements Serializable {
    
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private long insuranceId;
    
    private String planName = "planName";
    private String company = "company";
    
    @ManyToMany(targetEntity=User.class, fetch=FetchType.LAZY, cascade=CascadeType.ALL)
    private final Set<User> users = new HashSet<User>();
    
    public long getInsuranceId() {
        return insuranceId;
    }
    
    public void setInsuranceId(long insuranceId) {
        this.insuranceId = insuranceId;
    }
    
    public String getCompany() {
        return company;
    }
    
    public void setCompany(String company) {
        if (company != null && !company.trim().isEmpty()) {
            this.company = company.trim();
        }
    }
    
    public String getPlanName() {
        return planName;
    }

    public void setPlanName(String planName) {
        if (planName != null && !planName.trim().isEmpty()) {
            this.planName = planName;
        }
    }
    
    public Set<User> getUsers() {
        return users;
    }
    
    public void addUser(User user) {
        if (user != null) {
            switch(user.type()) {
                case CUSTOMER:
                    Customer c = (Customer) user;
                    if (!c.getInsurances().contains(this)) {
                        c.addInsurance(this);
                    }
                    break;
                case PROVIDER:
                    Provider p = (Provider) user;
                    //  TODO: Finish
                    break;
                case PRACTICE:
                    Practice pr = (Practice) user;
                    if (!pr.getAcceptedInsurances().contains(this)) {
                        pr.addAcceptedInsurance(this);
                    }
                    break;
                default:
                    break;
            }
            users.add(user);
        }
    }
    
    /** Comparator function to compare Insurance objects based on
     *  company & plan name
     * @param o the Insurance object to compare to this object
     * @return true if the plan name & company equal this plan & company
     */
    @Override
    public boolean equals(Object o) {
        if (o != null && o instanceof Insurance) {
            Insurance a = (Insurance) o;
            String compA = a.getCompany();
            String planA = a.getPlanName();
            
            if (compA.equals(company) && planA.equals(planName))
                return true;
        }
        
        return false;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + (this.planName != null ? this.planName.hashCode() : 0);
        hash = 97 * hash + (this.company != null ? this.company.hashCode() : 0);
        return hash;
    }
}
