/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.business;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;

/**
 *
 * @author kbuck
 */
@Entity
public class Practice extends User {
    
    private String biography = "";
    
    @ManyToMany(targetEntity=Insurance.class)
    private final Set<Insurance> acceptedInsurance = new HashSet<Insurance>();
    
    @ManyToMany(targetEntity=Provider.class, fetch=FetchType.LAZY, cascade=CascadeType.ALL)
    private final Set<Provider> providersAtPractice = new HashSet<Provider>();
    
    public String getPracticeName() {
        return getFirstName();
    }
    
    public void setPracticeName(String practiceName) {
        if (practiceName != null && !practiceName.trim().isEmpty()) {
            this.setFirstName(practiceName.trim());
        }
    }
    
    public String getBiography() {
        return biography;
    }
    
    public void setBiography(String biography) {
        if (biography != null && !biography.trim().isEmpty()) {
            this.biography = biography;
        }
    }
    
    public Set<Insurance> getAcceptedInsurances() {
        return acceptedInsurance;
    }
    
    public void addAcceptedInsurance(Insurance insurance) {
        if (insurance != null) {
            if (!insurance.getUsers().contains(this)) {
                insurance.addUser(this);
            }
            if (!acceptedInsurance.contains(insurance)) {
                acceptedInsurance.add(insurance);
            }
        }
    }
    
    public void removeAcceptedInsurance(Insurance insurance) {
        if (insurance != null) {
            if (insurance.getUsers().contains(this)) {
                insurance.getUsers().remove(this);
            }
            if (acceptedInsurance.contains(insurance)) {
                acceptedInsurance.remove(insurance);
            }
        }
    }
    
    public Set<Provider> getProvidersAtPractice() {
        return providersAtPractice;
    }
    
    public void addProviderAtPractice(Provider provider) {
        if (provider != null) {
            if (!provider.getPracticesWorkedAt().contains(this)) {
                provider.addPracticeWorkedAt(this);
            }
            if (!providersAtPractice.contains(provider)) {
                providersAtPractice.add(provider);
            }
        }
    }
    
    public void removeProviderAtPractice(Provider provider) {
        if (provider != null) {
            if (provider.getPracticesWorkedAt().contains(this)) {
                provider.removePracticeWorkedAt(this);
            }
            if (providersAtPractice.contains(provider)) {
                providersAtPractice.remove(provider);
            }
        }
    }
    
    @Override
    public void setLastName(String lastName) {
        setPracticeName(lastName);
    }
    
    @Override
    public void setMidInit(String midInit) {
        //  Do Nothing
    }
    
    @Override
    public String getLastName() {
        return getPracticeName();
    }
    
    @Override
    public String getMidInit() {
        return "";
    }

    /**
     *
     * @return
     */
    @Override
    public UserType type() {
        return UserType.PRACTICE;
    }
}
