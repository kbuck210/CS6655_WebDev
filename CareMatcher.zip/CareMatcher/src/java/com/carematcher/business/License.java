/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.business;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

/**
 *
 * @author kbuck
 */
@Entity
public class License implements Serializable {
    
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private long licenseId;
    
    private String licenseName = "";
    private String licenseDescription = "";
    
    @ManyToMany(targetEntity=Provider.class, fetch=FetchType.LAZY, cascade=CascadeType.ALL)
    private final Set<Provider> providersWithLicense = new HashSet<Provider>();
    
    public long getLicenseId() {
        return licenseId;
    }
    
    public void setLicenseId(long licesneId) {
        this.licenseId = licesneId;
    }
    
    public String getLicenseName() {
        return licenseName;
    }
    
    public void setLicenseName(String licenseName) {
        if (licenseName != null && !licenseName.trim().isEmpty()) {
            this.licenseName = licenseName;
        }
    }
    
    public String getLicenseDescription() {
        return licenseDescription;
    }
    
    public void setLicenseDescription(String licenseDescription) {
        if (licenseDescription != null && !licenseDescription.trim().isEmpty()) {
            this.licenseDescription = licenseDescription;
        }
    }
    
    public Set<Provider> getProvidersWithLicense() {
        return providersWithLicense;
    }
    
    public void addProviderWithLicense(Provider provider) {
        if (provider != null) {
            if (!provider.getLicenses().contains(this)) {
                provider.addLicense(this);
            }
            if (!providersWithLicense.contains(provider)) {
                providersWithLicense.add(provider);
            }
        }
    }
    
    public void removeProviderWithLicense(Provider provider) {
        if (provider != null) {
            if (provider.getLicenses().contains(this)) {
                provider.removeLicense(this);
            }
            if (providersWithLicense.contains(provider)) {
                providersWithLicense.remove(provider);
            }
        }
    }
}
