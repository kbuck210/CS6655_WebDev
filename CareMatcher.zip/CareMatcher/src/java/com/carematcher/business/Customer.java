/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.business;

import com.carematcher.util.CalUtil;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/** The main Customer class, extension of the User class, storing customer- 
 * specific attributes
 * @author kbuck
 */
@Entity
public class Customer extends User {
    
    @Temporal(TemporalType.DATE)
    private GregorianCalendar dateOfBirth = new GregorianCalendar();
    
    private String image = "placeholder";
    
    @OneToMany(targetEntity=Review.class)
    private final List<Review> reviews = new ArrayList<Review>();
    
    @ManyToMany(targetEntity=Service.class)
    private final Set<Service> servicesDesired = new HashSet<Service>();
    
    @ManyToMany(targetEntity=Insurance.class)
    private final Set<Insurance> insurances = new HashSet<Insurance>();
    
    public Calendar getDateOfBirth() {
        return dateOfBirth;
    }
    
    public void setDateOfBirth(int month, int day, int year) {
        CalUtil calendar = new CalUtil(day, month, year);
        if (calendar.isValidDate()) {
            this.dateOfBirth = (GregorianCalendar) calendar;
        }
    }
    
    /* --------------------------------------------------------------------
     *  Image
     * -------------------------------------------------------------------- */
    public void setImage(String placeholder) {
        image = placeholder;
    }
    
    public String getImage() {
        return image;
    }
    
    /* --------------------------------------------------------------------
     *  Insurances
     * -------------------------------------------------------------------- */
    public Set<Insurance> getInsurances() {
        return insurances;
    }
    
    public void addInsurance(Insurance insurance) {
        if (insurance != null) {
            if (!insurance.getUsers().contains(this)) {
                insurance.addUser(this);
            }
            if (!insurances.contains(insurance)) {
                insurances.add(insurance);
            }
        }
    }
    
    public void removeInsurance(Insurance insurance) {
        if (insurance != null) {
            if (insurance.getUsers().contains(this)) {
                insurance.getUsers().remove(this);
            }
            if (insurances.contains(insurance)) {
                insurances.remove(insurance);
            }
        }
    }
    
    /* --------------------------------------------------------------------
     *  Reviews
     * -------------------------------------------------------------------- */
    public List<Review> getReviews() {
        return reviews;
    }
    
    public void addReview(Review review) {
        if (review != null) {
            if (review.getReviewingCustomer() != this) {
                review.setReviewingCustomer(this);
            }
            if (!reviews.contains(review)) {
                reviews.add(review);
            }
        }
    }
    
    public void removeReview(Review review) {
        if (review != null) {
            if (reviews.contains(review)) {
                reviews.remove(review);
                review.setReviewingCustomer(null);
            }
        }
    }
    
    /* --------------------------------------------------------------------
     *  Services Desired
     * -------------------------------------------------------------------- */
    public Set<Service> getServicesDesired() {
        return servicesDesired;
    }
    
    public void addServiceDesired(Service service) {
        if (service != null) {
            
        }
    }
    
    public void removeServiceDesired(Service service) {
        
    }

    @Override
    public UserType type() {
        return UserType.CUSTOMER;
    }
}
