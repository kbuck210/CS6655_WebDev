/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.business;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

/**
 *
 * @author kbuck
 */
@Entity
public class Service implements Serializable {
    
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private long serviceId;
    
    private String serviceName = "service";
    private String description = "description";
    
    private Set<String> categories = new HashSet<String>();
    
    @ManyToMany(targetEntity=Customer.class, fetch=FetchType.LAZY, cascade=CascadeType.ALL)
    private final Set<Customer> customers = new HashSet<Customer>();
    
    @ManyToMany(targetEntity=Provider.class, fetch=FetchType.LAZY, cascade=CascadeType.ALL)
    private final Set<Provider> providers = new HashSet<Provider>();
    
    @ManyToMany(targetEntity=Practice.class, fetch=FetchType.LAZY, cascade=CascadeType.ALL)
    private final Set<Practice> practices = new HashSet<Practice>();
    
    public long getServiceId() {
        return serviceId;
    }
    
    public void setServiceId(long serviceId) {
        this.serviceId = serviceId;
    }

    public String getServiceName() {
        return serviceName;
    }
    
    public void setServiceName(String serviceName) {
        if (serviceName != null && !serviceName.trim().isEmpty()) {
            this.serviceName = serviceName;
        }
    }

    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        if (description != null && !description.trim().isEmpty()) {
            this.description = description;
        }
    }
    
    public Set<String> getCategories() {
        return categories;
    }
    
    public void setCategories(HashSet<String> categories) {
        if (categories != null) 
            this.categories = categories;
    }
    
    public void addCategory(String category) {
        if (category != null && !category.trim().isEmpty()){
            categories.add(category.trim());
        }
    }
    
    public Set<Customer> getCustomers() {
        return customers;
    }
    
    public void addCustomer(Customer customer) {
        if (customer != null) {
            if (!customer.getServicesDesired().contains(this)) {
                customer.addServiceDesired(this);
            }
            if (!customers.contains(customer)) {
                customers.add(customer);
            }
        }
    }
    
    public void removeCustomer(Customer customer) {
        if (customer != null) {
            if (customer.getServicesDesired().contains(this)) {
                customer.removeServiceDesired(this);
            }
            if (customers.contains(customer)) {
                customers.remove(customer);
            }
        }
    }
    
    public Set<Provider> getProviders() {
        return providers;
    }
    
    public void addProvider(Provider provider) {
        if (provider != null) {
            if (!provider.getServicesPerformed().contains(this)) {
                provider.addServicePerformed(this);
            }
            if (!providers.contains(provider)) {
                providers.add(provider);
            }
        }
    }
    
    public void removeProvider(Provider provider) {
        if (provider != null) {
            if (provider.getServicesPerformed().contains(this)) {
                provider.removeServicePerformed(this);
            }
            if (providers.contains(provider)) {
                providers.remove(provider);
            }
        }
    }
    
    public Set<Practice> getPractices() {
        return practices;
    }
    
    public void addPractice(Practice practice) {
        if (practice != null) {
            //
        }
    }
    
    public void removePractice(Practice practice) {
        
    }
}
