/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.carematcher.business;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/** Generic User class, to be extended by Customer, Provider & Practice
 *
 * @author kbuck
 */
@Entity
public abstract class User implements Serializable {
    
    public enum UserType {
        CUSTOMER,
        PROVIDER,
        PRACTICE
    }
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long userId;
    
    private String firstName = "firstName";
    private String lastName = "lastName";
    private String midInit = "";
    
    private String username = "username";
    private String password = "password";
    private String email = "email";
    
    
    @OneToMany(mappedBy="user")
    private final List<Address> addresses = new ArrayList<Address>();
    
    @OneToMany(mappedBy="user")
    private final List<Phone> phones = new ArrayList<Phone>();
    
    public long getUserId() {
        return userId;
    }
    
    public void setUserId(long userId) {
        this.userId = userId;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName) {
        if (firstName != null && !firstName.trim().isEmpty()) {
            this.firstName = firstName.trim();
        }
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        if (lastName != null && !lastName.trim().isEmpty()) {
            this.lastName = lastName.trim();
        }
    }

    public String getMidInit() {
        return midInit;
    }
    
    public void setMidInit(String midInit) {
        if (midInit != null && !midInit.trim().isEmpty()) {
            this.midInit = midInit.trim();
        }
    }

    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        if (username != null && !username.trim().isEmpty()) {
            this.username = username.trim();
        }
    }

    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        if (password != null && !password.trim().isEmpty()) {
            this.password = password;
        }
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        if (email != null && !email.trim().isEmpty()) {
            this.email = email;
        }
    }
    
    public List<Phone> getPhones() {
        return phones;
    }
    
    public void addPhone(Phone phone) {
        if (phone != null) {
            if (phone.getUser() != this) {
                phone.setUser(this);
            }
            if (!phones.contains(phone)) {
                phones.add(phone);
            }            
        }
    }
    
    public void removePhone(Phone phone) {
        if (phone != null) {
            if (phones.contains(phone)) {
                phones.remove(phone);
                phone.setUser(null);
            }
        }
    }
    
    public List<Address> getAddresses() {
        return addresses;
    }
    
    public void addAddress(Address address) {
        if (address != null) {
            if (address.getUser() != this) {
                address.setUser(this);
            }
            if (!addresses.contains(address)) {
                addresses.add(address);
            }
        }
    }
    
    public void removeAddress(Address address) {
        if (address != null) {
            if (addresses.contains(address)) {
                addresses.remove(address);
                address.setUser(null);
            }
        }
    }

    public abstract UserType type();
}
